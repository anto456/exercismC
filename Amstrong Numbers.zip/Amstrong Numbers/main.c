
/*
An Armstrong number is a number that is the sum of its own digits each raised to the power of the number of digits.

For example:

9 is an Armstrong number, because 9 = 9^1 = 9
10 is not an Armstrong number, because 10 != 1^2 + 0^2 = 1
153 is an Armstrong number, because: 153 = 1^3 + 5^3 + 3^3 = 1 + 125 + 27 = 153
154 is not an Armstrong number, because: 154 != 1^3 + 5^3 + 4^3 = 1 + 125 + 64 = 190
Write some code to determine whether a number is an Armstrong number.
 */
#include <stdio.h>
#define TOT 10
void contacifre(int,int*);
void azzeradigits();
int digits[TOT];
int Amstrong(int,int);
int power (int,int);
int main() {
    int numero,cifre;
    azzeradigits();
    printf("Inserisci un numero:");
    scanf("%d",&numero);
    contacifre(numero,&cifre);
    printf("Numero di cifre = %d\n",cifre);
    if (Amstrong(numero,cifre)) printf("%d e' un numero di Amstrong\n",numero);
    else printf("%d non e' un numero di Amstrong\n",numero);
    return 0;
}

void contacifre(int numero,int *cifre){
   int q,r,pos=TOT-1,cif=0;
   q=numero;
   while (q>0) {
       r=q%10;
       digits[pos]=r;
       q=q/10;
       pos--;
       cif++;
   }
   *cifre=cif;
}

void azzeradigits(){
    int i;
    for (i=0;i<TOT;i++) digits[i]=0;
}
int power(int b,int e){
    int prod=1,i;
    for (i=1;i<=e;i++) prod*=b;
    return prod;
}
int Amstrong(int numero,int cifre){
    int check=0;
    int start=TOT-cifre;
    int sum=0;
    while (start < TOT) {
        printf("%d^%d+",digits[start],cifre);
        sum=sum+power(digits[start],cifre);
        start++;
    }
    printf("=%d\n",sum);
    if (numero==sum) check=1;
    return check;
}