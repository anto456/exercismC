/*
 * Calculate the Hamming Distance between two DNA strands.

Your body is made up of cells that contain DNA. Those cells regularly wear out and need replacing,
 which they achieve by dividing into daughter cells. In fact, the average human body experiences about 10 quadrillion cell divisions in a lifetime!

When cells divide, their DNA replicates too. Sometimes during this process mistakes happen and single pieces of DNA get encoded with the incorrect information.
 If we compare two strands of DNA and count the differences between ,them we can see how many mistakes occurred. This is known as the "Hamming Distance".

We read DNA using the letters C,A,G and T. Two strands might look like this:

GAGCCTACTAACGGGAT
CATCGTAATGACGGCCT
^ ^ ^  ^ ^    ^^
They have 7 differences, and therefore the Hamming Distance is 7.

The Hamming Distance is useful for lots of things in science, not just biology, so it's a nice phrase to be familiar with :)

Implementation notes
The Hamming distance is only defined for sequences of equal length, so an attempt to calculate it between sequences of different lengths should not work.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int checkstr(char *st,const char letters[]){
   int len=(int) strlen(st);
   int i,k;
   int exact=1,present;
   i=0;
   while ((i<len)&&(exact)){
       present=0;
       k=0;
       while ((k<8)&&(!present)){
           if (st[i]==letters[k]) present=1;
           else k++;
       }
       if (!present) exact=0;
       i++;
   }
   return exact;
}
int hamming(char *left,char *right){
    int count=0;
    for (int i=0;i<(int)strlen(left);i++){
        if (left[i]!=right[i]) count++;
    }
    return count;
}
int main() {
    char letters[8]={'C','G','A','T','c','g','a','t'};
    char st1[80],st2[80],*dna1,*dna2;
    do {
        printf("Stringa DNA n.1:\n");
        gets(st1);
    } while (!checkstr(st1,letters));
    do {
        printf("Stringa DNA n.2:\n");
        gets(st2);
    } while (!checkstr(st2,letters));
    if (strlen(st1)!=strlen(st2)) exit(0);
    dna1=strupr(st1);
    dna2=strupr(st2);
    printf("Distanza di Hamming = %d\n",hamming(dna1,dna2));
    return 0;
}
