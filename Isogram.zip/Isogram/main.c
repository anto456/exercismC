//Determine if a word or phrase is an isogram.
//
//An isogram (also known as a "non-pattern word") is a word or phrase without a repeating letter,
// however spaces and hyphens are allowed to appear multiple times.
//
//Examples of isograms:
//
//lumberjacks
//background
//downupream
//six-year-old
//The word isograms, however, is not an isogram, because the s repeats.

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main() {
    char str[80], *upr,ch;

    int i=0,k;
    int iso=1;
    printf("Inserisci una stringa:\n");
    gets(str);
    bool exist;
    upr=strupr(str);
    while ((i<(int)strlen(upr)&&iso)) {
        ch = upr[i];
        if ((ch!=' ')&&(ch!='-')){
            k=i+1;
            exist=false;
            while(k<(int)strlen(upr)&&!exist){
                if (upr[k]==ch) exist=true;
                else k++;
            }
            if (exist) {iso=false;}
            else i++;
        }
        else i++;
    }
    if (iso) printf("ISOGRAM=TRUE\n");
    else printf("ISOGRAM=FALSE\n");
    return 0;
}
